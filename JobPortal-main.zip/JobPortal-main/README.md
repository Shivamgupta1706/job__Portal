# Job-Portal

The online job portal application allows job seekers and recruiters to connect.The application provides the ability for job seekers to create their accounts, upload their profile and resume, search for jobs, apply for jobs, view different job openings. The application provides the ability for companies to create their accounts, search candidates, create job postings, and view candidates applications.

# admin password
un: admin
password: 123456

By: Sudarshan Pandey
For Synopsis | PPT | Project Report
Contact: chap3219@gmail.com

credit https://github.com/fulfilen
